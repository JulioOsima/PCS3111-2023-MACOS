#include "CircuitoMISO.h"

CircuitoMISO::CircuitoMISO() : Circuito(){

}

CircuitoMISO::~CircuitoMISO(){

}

int Circuito::getID(){
    return ID;
}
