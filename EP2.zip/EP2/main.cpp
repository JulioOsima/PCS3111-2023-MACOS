#include <iostream>
// Para compilar: g++ -std=c++11 *.cpp -o ep2
void menu();

int main(){
    menu();
    return 0;
}