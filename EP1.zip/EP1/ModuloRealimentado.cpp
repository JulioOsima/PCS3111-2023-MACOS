#include "ModuloRealimentado.h"
#include <iostream>
#include <string>

using namespace std;

ModuloRealimentado::ModuloRealimentado(double ganho) : 
ganho(ganho){
// ... 
}

ModuloRealimentado::~ModuloRealimentado(){
// ...
}

Sinal* ModuloRealimentado::processar(Sinal* sinalIN){
// ... adicionar o resto do metodo




}
