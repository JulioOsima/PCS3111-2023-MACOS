void menu(); // Preciso declarar as outras funções aqui???

int main() {
    menu();
    return 0;
}