void teste1();
void teste2();

int main() {
    teste1(); // Substitua pelo teste que deseja efetuar
    return 0;
}