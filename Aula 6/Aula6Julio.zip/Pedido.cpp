//Faca os includes necessarios
//Implemente aqui os metodos
#include "Pedido.h"

Pedido::Pedido(int quantidadeMaxima) {
    // implemente
}

Pedido::~Pedido() {
    // implemente
}

bool Pedido::adicionar(Produto *p) {
    // implemente
    return false;
}

bool Pedido::remover(Produto *p) {
    // implemente
    return false;
}

Produto** Pedido::getProdutos() {
    return nullptr;
}

int Pedido::getQuantidadeDeProdutos() {
    return -1;
}

double Pedido::getValor() {
    return -1;
}

void Pedido::imprimir() {
    cout << "Pedido com " << getQuantidadeDeProdutos() << " produto(s) - " << getValor() << " reais" << endl;
    for (int i = 0; i < getQuantidadeDeProdutos(); i++)
        getProdutos()[i]->imprimir();
    cout << endl;
}