#include "CircuitoMISO.h"

CircuitoMISO::CircuitoMISO() : Circuito(){

}

CircuitoMISO::~CircuitoMISO(){

}


