#include "CircuitoSISO.h"

CircuitoSISO::CircuitoSISO() : Circuito(){
    // n faz nada
}

CircuitoSISO::~CircuitoSISO(){
    // tbm n faz nada
}

void CircuitoSISO::imprimir(){
}
